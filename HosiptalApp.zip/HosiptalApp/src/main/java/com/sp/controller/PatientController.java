package com.sp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sp.dao.PatientDao;
import com.sp.model.Patient;

@Controller
public class PatientController {
    @Autowired
	public PatientDao dao;
  @RequestMapping("/patientForm")
	public ModelAndView showForm() {
		return new ModelAndView("patientForm","command",new Patient());
	}
  @RequestMapping(value="/save",method=RequestMethod.POST)
  public ModelAndView save(@ModelAttribute("p") Patient p) {
 	dao.save(p);
 		return new ModelAndView("result","message","data has  been enter succesfully");
	}

}
