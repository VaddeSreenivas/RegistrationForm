package com.sp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hosiptal")
public class Patient {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
    private Integer pid;
	@Column(name="firstname")
    private String pfname;
	@Column(name="lastname")
    private String plname;
	@Column(name="address")
    private String padd;
	@Column(name="phonenumber")
    private Integer pphoneNo;
    
    public Patient() {
    	
    }
    
	public Patient(Integer pid, String pfname, String plname, String padd, Integer pphoneNo) {
		super();
		this.pid = pid;
		this.pfname = pfname;
		this.plname = plname;
		this.padd = padd;
		this.pphoneNo = pphoneNo;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPfname() {
		return pfname;
	}
	public void setPfname(String pfname) {
		this.pfname = pfname;
	}
	public String getPlname() {
		return plname;
	}
	public void setPlname(String plname) {
		this.plname = plname;
	}
	public String getPadd() {
		return padd;
	}
	public void setPadd(String padd) {
		this.padd = padd;
	}
	public Integer getPphoneNo() {
		return pphoneNo;
	}
	public void setPphoneNo(Integer pphoneNo) {
		this.pphoneNo = pphoneNo;
	}
        
}
